const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');
const fs = require('fs');

const STORAGE = './storage.json';
const CONFIG = './config.json';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('warrantcreate')
        .setDescription('Issue a warrant')
        .addIntegerOption(opt => opt.setName('robloxid').setRequired(true))
        .addStringOption(opt => opt.setName('reason').setRequired(true))
        .addIntegerOption(opt => opt.setName('level')),

    async execute(interaction) {
        const id = interaction.options.getInteger('robloxid');
        const reason = interaction.options.getString('reason');
        const level = interaction.options.getInteger('level') || 'LOW';

        const config = JSON.parse(fs.readFileSync(CONFIG));
        const channel = interaction.guild.channels.cache.get(config.warrantChannel);

        try {
            const userRes = await axios.get(`https://users.roblox.com/v1/users/${id}`);
            const username = userRes.data.name;

            const avatarRes = await axios.get(
                `https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${id}&size=420x420&format=Png`
            );

            const avatar = avatarRes.data.data[0].imageUrl;

            const embed = new EmbedBuilder()
                .setColor(0x1f8bff)
                .setAuthor({ name: '🚔 MDT DATABASE SYSTEM' })
                .setTitle(`WARRANT RECORD`)
                .setThumbnail(avatar)
                .addFields(
                    { name: '👤 SUBJECT', value: `**${username}**`, inline: true },
                    { name: '🆔 ID', value: id.toString(), inline: true },
                    { name: '⚠️ THREAT LEVEL', value: level.toString(), inline: true },
                    { name: '📄 CHARGES', value: `\`\`\`${reason}\`\`\`` }
                )
                .setFooter({ text: `Issued by ${interaction.user.tag}` })
                .setTimestamp();

            const msg = await channel.send({ embeds: [embed] });

            let data = fs.existsSync(STORAGE) ? JSON.parse(fs.readFileSync(STORAGE)) : {};
            data[id] = msg.id;
            fs.writeFileSync(STORAGE, JSON.stringify(data, null, 2));

            await interaction.reply({ content: '✅ Warrant issued.', ephemeral: true });

        } catch (err) {
            console.error(err);
            await interaction.reply({ content: 'Failed to fetch Roblox user.', ephemeral: true });
        }
    }
};
